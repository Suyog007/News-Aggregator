from django.shortcuts import render

# Create your views here.
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from datetime import datetime



from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
# from ecommerce import urls

from .forms import SignUpForm

def signup(request):
    DT = datetime.now()

    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save() #saves in database
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('http://127.0.0.1:8000')
    else:
        form = SignUpForm()


    context={
        'form': form,
        "time" : DT
      }
    return render(request, 'signup.html', context)







